"""Measure your search engine honestly.  Run:   python evaluate.py

Two query sets: (1) ENGLISH queries -> articles in the selected language (your main use case),
(2) same-language queries.

Reports, for TF-IDF, BM25 and a linear-scan baseline:
  * MRR       (Mean Reciprocal Rank: 1/rank of the first correct article, averaged)
  * Success@1 (fraction of queries whose #1 result is correct)
  * Success@3
  * average and 95th-percentile latency in milliseconds
"""
import argparse
import json
import statistics
import time

from dsa_index import InvertedIndex, Trie, linear_scan
from text_utils import load_articles, normalize


def evaluate(search_fn, queries, repeat):
    rr, s1, s3, times = [], 0, 0, []
    for item in queries:
        lang = item.get("lang")
        ranked = [doc_id for doc_id, _ in search_fn(item["q"], lang)]
        rel = set(item["relevant"])
        pos = next((i for i, d in enumerate(ranked[:10], 1) if d in rel), None)
        rr.append(1 / pos if pos else 0.0)
        s1 += pos == 1
        s3 += bool(pos and pos <= 3)
        for _ in range(repeat):
            t = time.perf_counter()
            search_fn(item["q"], lang)
            times.append((time.perf_counter() - t) * 1000)
    n = len(queries)
    times.sort()
    return {
        "MRR": sum(rr) / n,
        "Success@1": s1 / n,
        "Success@3": s3 / n,
        "avg_ms": statistics.mean(times),
        "p95_ms": times[int(0.95 * (len(times) - 1))],
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="../data/sample_articles.jsonl")
    ap.add_argument("--queries", nargs="+",
                    default=["../eval/queries_en.json", "../eval/queries.json"],
                    help="English->target-language queries first, then same-language queries")
    ap.add_argument("--repeat", type=int, default=20, help="timing repetitions per query")
    args = ap.parse_args()

    articles = load_articles(args.data)

    t = time.perf_counter()
    idx = InvertedIndex()
    for a in articles:
        idx.add_document(a["id"], a["title"], a["text"], a["lang"], a.get("title_en", ""))
    idx.finalize()
    build_s = time.perf_counter() - t
    norm_docs = [(a["id"], a["lang"], normalize(a["title"] + " " + a.get("title_en", "") + " " + a["text"])) for a in articles]

    print(f"Articles: {len(articles)} | Index build: {build_s:.3f}s | Unique terms: {len(idx.postings)}")
    systems = {
        "TF-IDF (own index)": lambda q, l: idx.search(q, 10, "tfidf", l),
        "BM25   (own index)": lambda q, l: idx.search(q, 10, "bm25", l),
        "Linear scan (LIKE-style baseline)": lambda q, l: linear_scan(norm_docs, q, 10, l),
    }
    for qpath in args.queries:
        try:
            queries = json.load(open(qpath, encoding="utf-8"))
        except FileNotFoundError:
            continue
        print(f"\n== {qpath}  ({len(queries)} queries) ==")
        print(f"{'System':36}{'MRR':>7}{'S@1':>7}{'S@3':>7}{'avg ms':>9}{'p95 ms':>9}")
        for name, fn in systems.items():
            m = evaluate(fn, queries, args.repeat)
            print(f"{name:36}{m['MRR']:7.3f}{m['Success@1']:7.3f}{m['Success@3']:7.3f}"
                  f"{m['avg_ms']:9.3f}{m['p95_ms']:9.3f}")

    trie = Trie()
    for a in articles:
        trie.insert(a["title"])
    print("\nTrie demo  prefix 'है' ->", trie.starts_with("है"))
    en = Trie()
    for a in articles:
        if a.get("title_en"):
            en.insert(a["title_en"])
    print("Trie demo  prefix 'ta' (English) ->", en.starts_with("ta"))


if __name__ == "__main__":
    main()
