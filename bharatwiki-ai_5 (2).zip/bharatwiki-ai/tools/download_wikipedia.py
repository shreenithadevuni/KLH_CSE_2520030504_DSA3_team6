"""Download a SUBSET of real Wikipedia (Hindi, Telugu, Tamil, Kannada) into one JSONL file.

    pip install datasets
    python download_wikipedia.py --per-lang 10000 --out ../data/articles.jsonl

Source: Hugging Face dataset "wikimedia/wikipedia" (cleaned Wikimedia dumps, snapshot 20231101).
Check the dataset page for the newest snapshot name if this one is unavailable.
Wikipedia text is CC BY-SA - keep the 'url' field and mention the source in your report.
"""
import argparse
import json
from urllib.parse import quote

from datasets import load_dataset


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--langs", nargs="+", default=["hi", "te", "ta", "kn"])
    ap.add_argument("--per-lang", type=int, default=10000)
    ap.add_argument("--snapshot", default="20231101")
    ap.add_argument("--min-chars", type=int, default=300, help="skip very short stub articles")
    ap.add_argument("--max-chars", type=int, default=6000, help="truncate very long articles")
    ap.add_argument("--out", default="../data/articles.jsonl")
    args = ap.parse_args()

    with open(args.out, "w", encoding="utf-8") as out:
        for lang in args.langs:
            ds = load_dataset("wikimedia/wikipedia", f"{args.snapshot}.{lang}", split="train", streaming=True)
            kept = 0
            for row in ds:
                text = (row["text"] or "").strip()
                if len(text) < args.min_chars:
                    continue
                rec = {
                    "id": f"{lang}-{row['id']}",
                    "lang": lang,
                    "title": row["title"],
                    "text": text[: args.max_chars],
                    "url": f"https://{lang}.wikipedia.org/wiki/{quote(row['title'].replace(' ', '_'))}",
                }
                out.write(json.dumps(rec, ensure_ascii=False) + "\n")
                kept += 1
                if kept >= args.per_lang:
                    break
            print(f"{lang}: kept {kept} articles")


if __name__ == "__main__":
    main()
