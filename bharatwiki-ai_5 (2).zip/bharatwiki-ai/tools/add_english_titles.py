"""Add an English title (title_en) to every article, using Wikipedia's own language links.

    python add_english_titles.py --in ../data/articles.jsonl --out ../data/articles_en.jsonl

Why: your users type ENGLISH ("Taj Mahal") and pick a target language. Every Hindi/Telugu/Tamil/Kannada
Wikipedia article that has an English counterpart links to it (the "In other languages" list). We read those
links from the MediaWiki API and store the English title next to the article. The search engine then matches
the English query against title_en (keyword route) and against meaning (semantic route).

Articles without an English counterpart keep title_en = "" - they are still found by the semantic route.
Needs internet. About 50 titles per request, so 10,000 articles take roughly 200 requests per language.
"""
import argparse
import json
import time
import urllib.parse
import urllib.request

USER_AGENT = "BharatWikiAI-student-project/1.0 (educational use)"  # Wikimedia asks for a descriptive agent


def parse_response(resp: dict) -> dict[str, str]:
    """MediaWiki API (formatversion=2) response -> {source title: english title}."""
    query = resp.get("query", {})
    alias = {n["to"]: n["from"] for n in query.get("normalized", [])}
    out = {}
    for page in query.get("pages", []):
        links = page.get("langlinks") or []
        if links:
            title = page["title"]
            out[alias.get(title, title)] = links[0]["title"]
    return out


def fetch_batch(lang: str, titles: list[str]) -> dict[str, str]:
    result: dict[str, str] = {}
    cont: dict = {}
    while True:
        params = {
            "action": "query", "format": "json", "formatversion": "2",
            "prop": "langlinks", "lllang": "en", "lllimit": "max",
            "titles": "|".join(titles), **cont,
        }
        url = f"https://{lang}.wikipedia.org/w/api.php?" + urllib.parse.urlencode(params)
        req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
        with urllib.request.urlopen(req, timeout=30) as r:
            resp = json.load(r)
        result.update(parse_response(resp))
        if "continue" not in resp:
            return result
        cont = resp["continue"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="inp", default="../data/articles.jsonl")
    ap.add_argument("--out", default="../data/articles_en.jsonl")
    ap.add_argument("--batch", type=int, default=50)
    ap.add_argument("--pause", type=float, default=0.2, help="seconds between requests (be polite)")
    args = ap.parse_args()

    articles = [json.loads(l) for l in open(args.inp, encoding="utf-8") if l.strip()]
    by_lang: dict[str, list[dict]] = {}
    for a in articles:
        by_lang.setdefault(a["lang"], []).append(a)

    for lang, items in by_lang.items():
        found = 0
        for i in range(0, len(items), args.batch):
            chunk = items[i : i + args.batch]
            mapping = fetch_batch(lang, [a["title"] for a in chunk])
            for a in chunk:
                a["title_en"] = mapping.get(a["title"], "")
                found += bool(a["title_en"])
            time.sleep(args.pause)
        print(f"{lang}: {found}/{len(items)} articles have an English title")

    with open(args.out, "w", encoding="utf-8") as f:
        for a in articles:
            f.write(json.dumps(a, ensure_ascii=False) + "\n")


if __name__ == "__main__":
    main()
