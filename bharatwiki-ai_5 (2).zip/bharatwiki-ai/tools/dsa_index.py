"""Data-structure part of the project (DSA-3), written from scratch:

  * InvertedIndex  - HashMap: term -> postings list [(doc_no, term_frequency)]
  * TF-IDF and BM25 ranking over that index
  * Top-K selection with a MIN-HEAP  (O(n log k) instead of sorting everything)
  * Trie           - prefix search for autocomplete
  * linear_scan    - naive baseline (like SQL  LIKE '%word%'), to prove the index is worth it
"""
import heapq
import math
from collections import Counter, defaultdict

from text_utils import normalize, tokenize


def top_k(scores: dict, k: int) -> list[tuple[float, int]]:
    """Return the k best (score, doc_no) pairs using a min-heap of size k."""
    heap: list[tuple[float, int]] = []
    for doc_no, score in scores.items():
        if len(heap) < k:
            heapq.heappush(heap, (score, doc_no))
        elif score > heap[0][0]:
            heapq.heapreplace(heap, (score, doc_no))
    return sorted(heap, reverse=True)


class InvertedIndex:
    def __init__(self, k1: float = 1.2, b: float = 0.75):
        self.k1, self.b = k1, b
        self.postings: dict[str, list[tuple[int, int]]] = defaultdict(list)
        self.doc_ids: list[str] = []
        self.doc_lang: list[str] = []
        self.doc_len: list[int] = []
        self.avg_len = 0.0

    # ---- building -------------------------------------------------------
    def add_document(self, doc_id: str, title: str, text: str, lang: str = "", title_en: str = "") -> None:
        doc_no = len(self.doc_ids)
        # titles (local + English) counted twice -> title words matter a little more.
        # The English title is what lets an ENGLISH query find a Hindi/Telugu/Tamil/Kannada article.
        tokens = tokenize(title) * 2 + tokenize(title_en) * 2 + tokenize(text)
        self.doc_ids.append(doc_id)
        self.doc_lang.append(lang)
        self.doc_len.append(len(tokens))
        for term, tf in Counter(tokens).items():
            self.postings[term].append((doc_no, tf))

    def finalize(self) -> None:
        self.avg_len = sum(self.doc_len) / max(1, len(self.doc_len))

    # ---- scoring --------------------------------------------------------
    def _idf_tfidf(self, df: int) -> float:
        return math.log(len(self.doc_ids) / df)

    def _idf_bm25(self, df: int) -> float:
        n = len(self.doc_ids)
        return math.log(1 + (n - df + 0.5) / (df + 0.5))

    def search(self, query: str, k: int = 10, scorer: str = "bm25", lang: str | None = None) -> list[tuple[str, float]]:
        scores: dict[int, float] = defaultdict(float)
        for term in set(tokenize(query)):
            plist = self.postings.get(term)
            if not plist:
                continue
            df = len(plist)
            for doc_no, tf in plist:
                if lang and self.doc_lang[doc_no] != lang:
                    continue  # only return articles in the language the user selected
                if scorer == "tfidf":
                    # (1 + log tf) * idf, divided by sqrt(doc length) as a simple length norm
                    scores[doc_no] += (1 + math.log(tf)) * self._idf_tfidf(df) / math.sqrt(self.doc_len[doc_no])
                else:
                    dl = self.doc_len[doc_no]
                    denom = tf + self.k1 * (1 - self.b + self.b * dl / self.avg_len)
                    scores[doc_no] += self._idf_bm25(df) * tf * (self.k1 + 1) / denom
        return [(self.doc_ids[d], s) for s, d in top_k(scores, k)]


def linear_scan(norm_docs: list[tuple[str, str, str]], query: str, k: int = 10, lang: str | None = None) -> list[tuple[str, float]]:
    """Baseline: scan EVERY document for every query word (what LIKE '%word%' does).
    norm_docs = [(doc_id, lang, normalize(title + ' ' + title_en + ' ' + text)), ...]"""
    q_tokens = set(tokenize(query))
    scores = {}
    for i, (_, doc_lang, text) in enumerate(norm_docs):
        if lang and doc_lang != lang:
            continue
        s = sum(text.count(t) for t in q_tokens)
        if s:
            scores[i] = float(s)
    return [(norm_docs[d][0], s) for s, d in top_k(scores, k)]


class Trie:
    """Prefix tree used for autocomplete on article titles."""

    class _Node:
        __slots__ = ("children", "titles")

        def __init__(self):
            self.children: dict[str, "Trie._Node"] = {}
            self.titles: list[str] = []

    def __init__(self):
        self.root = Trie._Node()

    def insert(self, title: str) -> None:
        node = self.root
        for ch in normalize(title):
            node = node.children.setdefault(ch, Trie._Node())
        node.titles.append(title)

    def starts_with(self, prefix: str, limit: int = 8) -> list[str]:
        node = self.root
        for ch in normalize(prefix):
            node = node.children.get(ch)
            if node is None:
                return []
        out: list[str] = []
        stack = [node]
        while stack and len(out) < limit:
            cur = stack.pop()
            out.extend(cur.titles)
            stack.extend(reversed(list(cur.children.values())))
        return out[:limit]
