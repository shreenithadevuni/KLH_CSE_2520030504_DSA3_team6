"""Optional meaning-based (semantic) search service.   Run:

    pip install fastapi uvicorn sentence-transformers numpy
    python -m uvicorn semantic_service:app --port 8001

The Spring Boot backend calls  GET /semantic?q=...&lang=hi&k=50  and mixes the result with BM25
(hybrid search).  If this service is not running, the backend simply uses keyword search only.

Cross-lingual: an English query like "white marble tomb in Agra" is close in meaning to the Telugu or Tamil
article about the Taj Mahal, because the model puts all languages in one shared meaning space.

How it works: every article is turned into a vector (embedding) by a multilingual model, so texts
with similar MEANING are close together.  A query is embedded the same way and compared by cosine
similarity.  For a student-size subset a plain numpy matrix is enough (no vector DB needed).
"""
import hashlib
import os
from pathlib import Path

import numpy as np
from fastapi import FastAPI, Query
from sentence_transformers import SentenceTransformer

from text_utils import load_articles

DATA = os.environ.get("DATA_PATH", "../data/sample_articles.jsonl")
MODEL = os.environ.get("EMBED_MODEL", "intfloat/multilingual-e5-small")
CACHE = Path(".cache")
CACHE.mkdir(exist_ok=True)

articles = load_articles(DATA)
model = SentenceTransformer(MODEL)

# e5 models expect the prefixes "passage: " / "query: "
# English title + local title + start of the text: lets an English query match Hindi/Telugu/Tamil/Kannada articles
docs = [f"passage: {a.get('title_en', '')}. {a['title']}. {a['text'][:500]}" for a in articles]
key = hashlib.md5(("v2" + MODEL + DATA + str(len(docs))).encode()).hexdigest()[:10]
cache_file = CACHE / f"emb-{key}.npy"
if cache_file.exists():
    matrix = np.load(cache_file)
else:
    print(f"Embedding {len(docs)} articles (one-time, cached afterwards)...")
    matrix = model.encode(docs, batch_size=32, normalize_embeddings=True, show_progress_bar=True)
    np.save(cache_file, matrix)

langs = np.array([a["lang"] for a in articles])
ids = [a["id"] for a in articles]
app = FastAPI(title="BharatWiki semantic service")


@app.get("/health")
def health():
    return {"status": "ok", "articles": len(ids), "model": MODEL}


@app.get("/semantic")
def semantic(q: str, lang: str = "all", k: int = Query(50, ge=1, le=200)):
    qv = model.encode([f"query: {q}"], normalize_embeddings=True)[0]
    sims = matrix @ qv
    if lang != "all":
        sims = np.where(langs == lang, sims, -1.0)
    top = np.argsort(-sims)[:k]
    return {"results": [{"id": ids[i], "score": float(sims[i])} for i in top if sims[i] > -1.0]}
