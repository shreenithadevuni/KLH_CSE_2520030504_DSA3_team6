"""Text cleaning + tokenization for Indian-language text (Hindi, Telugu, Tamil, Kannada).

Why a custom tokenizer?  Python's \\w does NOT match Indic vowel signs (combining marks),
so a regex like \\w+ would cut Hindi/Telugu/Tamil/Kannada words into pieces.
We keep every character whose Unicode category is Letter (L), Mark (M) or Number (N).
"""
import json
import unicodedata

# Tiny stop-word lists (most frequent function words). Extend them for real data.
STOPWORDS = {
    # Hindi
    "का", "के", "की", "में", "है", "और", "से", "को", "पर", "एक", "यह", "था", "थे", "भी", "कि", "हैं", "इस", "ने",
    # Telugu
    "మరియు", "ఒక", "ఈ", "ఆ", "లో", "కు", "నుండి", "ఉంది", "ఉంటాయి",
    # Tamil
    "ஒரு", "இது", "மற்றும்", "அது", "என்று", "இந்த", "ஆகும்",
    # Kannada
    "ಮತ್ತು", "ಒಂದು", "ಈ", "ಆ", "ಇದು", "ಎಂದು",
}

_INVISIBLE = {"\u200b", "\u200c", "\u200d", "\ufeff"}  # zero-width chars


def normalize(text: str) -> str:
    """Unicode NFC + remove zero-width characters + lowercase (for Latin text)."""
    text = unicodedata.normalize("NFC", text)
    text = "".join(ch for ch in text if ch not in _INVISIBLE)
    return text.lower()


def tokenize(text: str, remove_stopwords: bool = True) -> list[str]:
    tokens, cur = [], []
    for ch in normalize(text):
        if unicodedata.category(ch)[0] in "LMN":
            cur.append(ch)
        elif cur:
            tokens.append("".join(cur))
            cur = []
    if cur:
        tokens.append("".join(cur))
    if remove_stopwords:
        tokens = [t for t in tokens if t not in STOPWORDS]
    return tokens


def load_articles(path: str) -> list[dict]:
    articles = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                articles.append(json.loads(line))
    return articles
