package com.bharatwiki;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Prefix tree for autocomplete (DSA component). One Trie holds local titles, another English titles. */
public class Trie {
    public record Entry(String title, String titleEn, String lang, String id) {}

    private static class Node {
        final Map<Character, Node> children = new HashMap<>();
        final List<Entry> entries = new ArrayList<>();
    }

    private final Node root = new Node();

    public void insert(String key, Entry e) {
        Node node = root;
        for (char c : key.toLowerCase(Locale.ROOT).toCharArray()) {
            node = node.children.computeIfAbsent(c, k -> new Node());
        }
        node.entries.add(e);
    }

    /** Up to {@code limit} entries whose key starts with {@code prefix}; lang "all" means every language. */
    public List<Entry> startsWith(String prefix, String lang, int limit) {
        Node node = root;
        for (char c : prefix.toLowerCase(Locale.ROOT).toCharArray()) {
            node = node.children.get(c);
            if (node == null) return List.of();
        }
        List<Entry> out = new ArrayList<>();
        collect(node, lang, limit, out);
        return out;
    }

    private void collect(Node node, String lang, int limit, List<Entry> out) {
        if (out.size() >= limit) return;
        for (Entry e : node.entries) {
            if (out.size() >= limit) return;
            if (lang == null || lang.equals("all") || lang.equals(e.lang())) out.add(e);
        }
        for (Node child : node.children.values()) {
            if (out.size() >= limit) return;
            collect(child, lang, limit, out);
        }
    }
}
