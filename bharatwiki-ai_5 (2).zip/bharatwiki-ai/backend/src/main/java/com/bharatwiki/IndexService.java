package com.bharatwiki;

import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.en.EnglishAnalyzer;
import org.apache.lucene.analysis.miscellaneous.PerFieldAnalyzerWrapper;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.StringField;
import org.apache.lucene.document.TextField;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

/** Loads the JSONL articles and builds the Lucene inverted index at startup. */
@Service
public class IndexService {
    private static final Logger log = LoggerFactory.getLogger(IndexService.class);

    // Indic analyzer for the local-language fields, English analyzer (stop-words + stemming) for title_en
    private final Analyzer analyzer = new PerFieldAnalyzerWrapper(new IndicAnalyzer(), Map.of("title_en", new EnglishAnalyzer()));
    private final Map<String, Article> articles = new LinkedHashMap<>();
    private Directory directory;
    private DirectoryReader reader;

    @Value("${bharatwiki.data-path}")
    private String dataPath;
    @Value("${bharatwiki.index-dir}")
    private String indexDir;

    @PostConstruct
    void init() throws IOException {
        Path data = Path.of(dataPath);
        if (!Files.exists(data)) {
            throw new IllegalStateException("Data file not found: " + data.toAbsolutePath()
                    + "  (run the backend from the backend/ folder, or fix bharatwiki.data-path)");
        }
        ObjectMapper mapper = new ObjectMapper();
        for (String line : Files.readAllLines(data, StandardCharsets.UTF_8)) {
            if (line.isBlank()) continue;
            Article a = mapper.readValue(line, Article.class);
            articles.put(a.id(), a);
        }

        long t0 = System.currentTimeMillis();
        directory = FSDirectory.open(Path.of(indexDir));
        IndexWriterConfig cfg = new IndexWriterConfig(analyzer).setOpenMode(IndexWriterConfig.OpenMode.CREATE);
        try (IndexWriter writer = new IndexWriter(directory, cfg)) {
            for (Article a : articles.values()) {
                Document d = new Document();
                d.add(new StringField("id", a.id(), Field.Store.YES));
                d.add(new StringField("lang", a.lang(), Field.Store.YES));
                d.add(new TextField("title", a.title(), Field.Store.YES));
                if (a.titleEn() != null && !a.titleEn().isBlank()) {
                    d.add(new TextField("title_en", a.titleEn(), Field.Store.YES));
                }
                d.add(new TextField("text", a.text(), Field.Store.YES));
                writer.addDocument(d);
            }
            writer.commit();
        }
        reader = DirectoryReader.open(directory);
        log.info("Indexed {} articles in {} ms", articles.size(), System.currentTimeMillis() - t0);
    }

    @PreDestroy
    void close() throws IOException {
        if (reader != null) reader.close();
        if (directory != null) directory.close();
    }

    public Analyzer analyzer() { return analyzer; }
    public DirectoryReader reader() { return reader; }
    public Map<String, Article> articles() { return articles; }

    /** Number of articles per language (shown in the dashboard). */
    public Map<String, Long> corpusByLanguage() {
        Map<String, Long> m = new TreeMap<>();
        for (Article a : articles.values()) m.merge(a.lang(), 1L, Long::sum);
        return m;
    }
}
