package com.bharatwiki;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.Instant;

/** One row per search - this table feeds the analytics dashboard. */
@Entity
@Table(name = "search_log")
public class SearchLog {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "query_text", length = 500)
    private String queryText;
    @Column(name = "lang")
    private String lang;
    @Column(name = "search_mode")
    private String searchMode;
    @Column(name = "latency_ms")
    private double latencyMs;
    @Column(name = "result_count")
    private int resultCount;
    @Column(name = "created_at")
    private Instant createdAt = Instant.now();

    protected SearchLog() {}

    public SearchLog(String queryText, String lang, String searchMode, double latencyMs, int resultCount) {
        this.queryText = queryText.length() > 500 ? queryText.substring(0, 500) : queryText;
        this.lang = lang;
        this.searchMode = searchMode;
        this.latencyMs = latencyMs;
        this.resultCount = resultCount;
    }

    public Long getId() { return id; }
    public String getQueryText() { return queryText; }
    public String getLang() { return lang; }
    public String getSearchMode() { return searchMode; }
    public double getLatencyMs() { return latencyMs; }
    public int getResultCount() { return resultCount; }
    public Instant getCreatedAt() { return createdAt; }
}
