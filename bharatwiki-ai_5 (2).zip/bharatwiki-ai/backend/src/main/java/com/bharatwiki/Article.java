package com.bharatwiki;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * One Wikipedia article (a line of the JSONL data file).
 * titleEn = the English title of the same topic (may be empty); it lets an English query find this article.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public record Article(String id, String lang, String title,
                      @JsonProperty("title_en") String titleEn,
                      String text, String url) {}
