package com.bharatwiki;

import java.util.List;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface SearchLogRepository extends JpaRepository<SearchLog, Long> {

    @Query("select s.lang, count(s) from SearchLog s group by s.lang")
    List<Object[]> countByLang();

    @Query("select s.searchMode, count(s) from SearchLog s group by s.searchMode")
    List<Object[]> countByMode();

    @Query("select s.queryText, count(s) from SearchLog s group by s.queryText order by count(s) desc")
    List<Object[]> topQueries(Pageable pageable);

    @Query("select avg(s.latencyMs) from SearchLog s")
    Double avgLatency();

    List<SearchLog> findTop200ByOrderByCreatedAtDesc();
}
