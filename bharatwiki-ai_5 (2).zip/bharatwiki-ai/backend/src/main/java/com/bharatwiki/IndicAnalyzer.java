package com.bharatwiki;

import java.util.List;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.CharArraySet;
import org.apache.lucene.analysis.LowerCaseFilter;
import org.apache.lucene.analysis.StopFilter;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.Tokenizer;
import org.apache.lucene.analysis.in.IndicNormalizationFilter;
import org.apache.lucene.analysis.standard.StandardTokenizer;

/**
 * One analyzer for Hindi, Telugu, Tamil and Kannada:
 * Unicode word tokenizer -> lowercase -> Indic normalization -> small stop-word list.
 * (Lucene only ships a full analyzer for Hindi; this simple chain is used for all four languages.)
 */
public class IndicAnalyzer extends Analyzer {

    private static final CharArraySet STOP = new CharArraySet(List.of(
            // Hindi
            "का", "के", "की", "में", "है", "और", "से", "को", "पर", "एक", "यह", "था", "थे", "भी", "कि", "हैं", "इस", "ने",
            // Telugu
            "మరియు", "ఒక", "ఈ", "ఆ", "లో", "కు", "నుండి", "ఉంది", "ఉంటాయి",
            // Tamil
            "ஒரு", "இது", "மற்றும்", "அது", "என்று", "இந்த", "ஆகும்",
            // Kannada
            "ಮತ್ತು", "ಒಂದು", "ಈ", "ಆ", "ಇದು", "ಎಂದು"), true);

    @Override
    protected TokenStreamComponents createComponents(String fieldName) {
        Tokenizer source = new StandardTokenizer();
        TokenStream chain = new LowerCaseFilter(source);
        chain = new IndicNormalizationFilter(chain);
        chain = new StopFilter(chain, STOP);
        return new TokenStreamComponents(source, chain);
    }

    @Override
    protected TokenStream normalize(String fieldName, TokenStream in) {
        return new IndicNormalizationFilter(new LowerCaseFilter(in));
    }
}
