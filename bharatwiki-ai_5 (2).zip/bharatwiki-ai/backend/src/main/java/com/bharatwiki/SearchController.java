package com.bharatwiki;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class SearchController {
    private static final Logger log = LoggerFactory.getLogger(SearchController.class);

    private final SearchService search;
    private final IndexService index;
    private final SearchLogRepository logs;

    public SearchController(SearchService search, IndexService index, SearchLogRepository logs) {
        this.search = search;
        this.index = index;
        this.logs = logs;
    }

    /** mode = bm25 | tfidf | semantic | hybrid */
    @GetMapping("/search")
    public SearchService.Response search(@RequestParam String q,
                                         @RequestParam(defaultValue = "all") String lang,
                                         @RequestParam(defaultValue = "hybrid") String mode,
                                         @RequestParam(defaultValue = "10") int size) {
        SearchService.Response r = search.search(q, lang, mode, size);
        if (!r.query().isEmpty()) {
            try {
                logs.save(new SearchLog(r.query(), lang, mode, r.tookMs(), r.total()));
            } catch (Exception e) {
                log.warn("Could not save search log: {}", e.toString());
            }
        }
        return r;
    }

    @GetMapping("/suggest")
    public List<SearchService.Suggestion> suggest(@RequestParam String q,
                                                  @RequestParam(defaultValue = "all") String lang) {
        return search.suggest(q, lang);
    }

    public record ArticleView(String id, String lang, String title, String titleEn, String text, String url) {}

    /** Full text of one article (used by the "Read full article" button). */
    @GetMapping("/article")
    public ResponseEntity<ArticleView> article(@RequestParam String id) {
        Article a = index.articles().get(id);
        if (a == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(new ArticleView(a.id(), a.lang(), a.title(), a.titleEn(), a.text(), a.url()));
    }

    @GetMapping("/related")
    public List<SearchService.Hit> related(@RequestParam String id) {
        return search.related(id, 5);
    }

    @GetMapping("/analytics")
    public Map<String, Object> analytics() {
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("totalSearches", logs.count());
        Double avg = logs.avgLatency();
        out.put("avgLatencyMs", avg == null ? 0 : Math.round(avg * 100) / 100.0);

        List<Double> latencies = new ArrayList<>();
        logs.findTop200ByOrderByCreatedAtDesc().forEach(s -> latencies.add(s.getLatencyMs()));
        latencies.sort(Double::compare);
        out.put("p95LatencyMs", latencies.isEmpty() ? 0 : latencies.get((int) (0.95 * (latencies.size() - 1))));

        out.put("searchesByLanguage", toMap(logs.countByLang()));
        out.put("searchesByMode", toMap(logs.countByMode()));
        out.put("corpusByLanguage", index.corpusByLanguage());

        List<Map<String, Object>> top = new ArrayList<>();
        for (Object[] row : logs.topQueries(PageRequest.of(0, 8))) {
            top.add(Map.of("query", row[0], "count", row[1]));
        }
        out.put("topQueries", top);
        return out;
    }

    private static Map<String, Object> toMap(List<Object[]> rows) {
        Map<String, Object> m = new LinkedHashMap<>();
        for (Object[] r : rows) m.put(String.valueOf(r[0]), r[1]);
        return m;
    }
}
