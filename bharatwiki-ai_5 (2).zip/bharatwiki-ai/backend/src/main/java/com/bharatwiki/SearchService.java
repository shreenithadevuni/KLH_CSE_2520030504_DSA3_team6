package com.bharatwiki;

import jakarta.annotation.PostConstruct;
import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
import org.apache.lucene.index.Term;
import org.apache.lucene.queries.mlt.MoreLikeThis;
import org.apache.lucene.queryparser.classic.MultiFieldQueryParser;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.BooleanClause;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TermQuery;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.search.highlight.Highlighter;
import org.apache.lucene.search.highlight.QueryScorer;
import org.apache.lucene.search.highlight.SimpleFragmenter;
import org.apache.lucene.search.highlight.SimpleHTMLEncoder;
import org.apache.lucene.search.highlight.SimpleHTMLFormatter;
import org.apache.lucene.search.similarities.BM25Similarity;
import org.apache.lucene.search.similarities.ClassicSimilarity;
import org.springframework.stereotype.Service;

/** Keyword (BM25 / TF-IDF), semantic and hybrid search + snippets, summaries, related, suggestions. */
@Service
public class SearchService {

    public record Hit(String id, String lang, String title, String titleEn, String snippet, String summary, String url, double score) {}
    public record Response(String query, String mode, double tookMs, int total, List<Hit> hits, String note) {}
    /** label = text to put in the search box; local = the title in the article's own language. */
    public record Suggestion(String label, String local, String lang, String id) {}

    private static final int POOL = 50;   // candidates taken from each ranker
    private static final int RRF_K = 60;  // constant of Reciprocal Rank Fusion

    private final IndexService index;
    private final SemanticClient semantic;
    private final Trie trie = new Trie();          // local-language titles
    private final Trie trieEn = new Trie();        // English titles

    public SearchService(IndexService index, SemanticClient semantic) {
        this.index = index;
        this.semantic = semantic;
    }

    @PostConstruct
    void buildTrie() {
        for (Article a : index.articles().values()) {
            Trie.Entry e = new Trie.Entry(a.title(), a.titleEn(), a.lang(), a.id());
            trie.insert(a.title(), e);
            if (a.titleEn() != null && !a.titleEn().isBlank()) trieEn.insert(a.titleEn(), e);
        }
    }

    // ------------------------------------------------------------------ search
    public Response search(String q, String lang, String mode, int size) {
        long t0 = System.nanoTime();
        String query = q == null ? "" : q.trim();
        if (query.isEmpty()) return new Response("", mode, 0, 0, List.of(), "Type something to search.");
        String langFilter = (lang == null || lang.isBlank()) ? "all" : lang;
        int n = Math.max(1, Math.min(size, POOL));
        String note = null;

        try {
            boolean english = isLatin(query);   // English query -> match title_en; other scripts -> match local fields
            Query textQuery = parseText(query, english);
            List<SemanticClient.Scored> ranked;

            if ("semantic".equals(mode)) {
                Optional<List<SemanticClient.Scored>> s = semantic.search(query, langFilter, POOL);
                ranked = s.orElse(List.of());
                if (s.isEmpty()) note = "Semantic service is not running (start tools/semantic_service.py).";
            } else if ("hybrid".equals(mode)) {
                List<SemanticClient.Scored> lex = lexical(textQuery, langFilter, false);
                Optional<List<SemanticClient.Scored>> s = semantic.search(query, langFilter, POOL);
                if (s.isPresent()) {
                    ranked = fuse(lex, s.get());
                } else {
                    ranked = lex;
                    note = "Semantic service is not running - showing English-title keyword matches only. "
                            + "Start tools/semantic_service.py to find articles by meaning.";
                }
            } else {
                ranked = lexical(textQuery, langFilter, "tfidf".equals(mode));
            }

            List<Hit> hits = new ArrayList<>();
            for (SemanticClient.Scored s : ranked) {
                if (hits.size() >= n) break;
                Article a = index.articles().get(s.id());
                if (a == null) continue;
                // For an English query the Indic text has no matching words, so show the start of the article.
                String snip = english ? plainHead(a.text()) : snippet(textQuery, a.text());
                hits.add(new Hit(a.id(), a.lang(), a.title(), a.titleEn(), snip,
                        summarize(a.text(), english ? "" : query), a.url(), s.score()));
            }
            return new Response(query, mode, elapsedMs(t0), ranked.size(), hits, note);
        } catch (Exception e) {
            return new Response(query, mode, elapsedMs(t0), 0, List.of(), "Could not run this query: " + e.getMessage());
        }
    }

    private static double elapsedMs(long t0) {
        return Math.round((System.nanoTime() - t0) / 10_000.0) / 100.0;
    }

    private Query parseText(String q, boolean english) throws Exception {
        MultiFieldQueryParser parser = english
                ? new MultiFieldQueryParser(new String[] {"title_en"}, index.analyzer())
                : new MultiFieldQueryParser(new String[] {"title", "text"}, index.analyzer(),
                        Map.of("title", 2.0f, "text", 1.0f));
        return parser.parse(QueryParser.escape(q));
    }

    /** true if every letter of the query is Latin (i.e. the user typed English). */
    static boolean isLatin(String q) {
        boolean anyLetter = false;
        for (int i = 0; i < q.length(); ) {
            int cp = q.codePointAt(i);
            i += Character.charCount(cp);
            if (Character.isLetter(cp)) {
                anyLetter = true;
                if (Character.UnicodeScript.of(cp) != Character.UnicodeScript.LATIN) return false;
            }
        }
        return anyLetter;
    }

    private static String plainHead(String text) {
        String head = text.length() > 220 ? text.substring(0, 220) + "..." : text;
        return SimpleHTMLEncoder.htmlEncode(head);
    }

    private Query withLang(Query q, String lang) {
        if (lang == null || lang.equals("all")) return q;
        return new BooleanQuery.Builder()
                .add(q, BooleanClause.Occur.MUST)
                .add(new TermQuery(new Term("lang", lang)), BooleanClause.Occur.FILTER)
                .build();
    }

    private List<SemanticClient.Scored> lexical(Query textQuery, String lang, boolean tfidf) throws IOException {
        IndexSearcher searcher = new IndexSearcher(index.reader());
        searcher.setSimilarity(tfidf ? new ClassicSimilarity() : new BM25Similarity());
        TopDocs top = searcher.search(withLang(textQuery, lang), POOL);
        List<SemanticClient.Scored> out = new ArrayList<>();
        for (ScoreDoc sd : top.scoreDocs) {
            String id = searcher.storedFields().document(sd.doc, Set.of("id")).get("id");
            out.add(new SemanticClient.Scored(id, sd.score));
        }
        return out;
    }

    /** Reciprocal Rank Fusion: score(d) = sum over rankers of 1 / (60 + rank). */
    private List<SemanticClient.Scored> fuse(List<SemanticClient.Scored> a, List<SemanticClient.Scored> b) {
        Map<String, Double> fused = new HashMap<>();
        for (List<SemanticClient.Scored> list : List.of(a, b)) {
            for (int i = 0; i < list.size(); i++) {
                fused.merge(list.get(i).id(), 1.0 / (RRF_K + i + 1), Double::sum);
            }
        }
        List<SemanticClient.Scored> out = new ArrayList<>();
        fused.forEach((id, score) -> out.add(new SemanticClient.Scored(id, score)));
        out.sort(Comparator.comparingDouble(SemanticClient.Scored::score).reversed());
        return out;
    }

    // ------------------------------------------------------- snippet / summary
    /** Best matching fragment with <mark> tags. Everything else is HTML-escaped, so it is safe to render. */
    private String snippet(Query textQuery, String text) {
        try {
            Highlighter h = new Highlighter(new SimpleHTMLFormatter("<mark>", "</mark>"),
                    new SimpleHTMLEncoder(), new QueryScorer(textQuery, "text"));
            h.setTextFragmenter(new SimpleFragmenter(220));
            String fragment = h.getBestFragment(index.analyzer(), "text", text);
            if (fragment != null) return fragment;
        } catch (Exception ignored) {
            // fall through to plain beginning of the text
        }
        String head = text.length() > 220 ? text.substring(0, 220) + "..." : text;
        return SimpleHTMLEncoder.htmlEncode(head);
    }

    /** Extractive, query-biased summary: the 2 sentences that share most words with the query. */
    String summarize(String text, String query) {
        String[] sentences = text.split("(?<=[\u0964.!?])\\s+");
        if (sentences.length <= 2) return text;
        Set<String> queryTerms = new HashSet<>(analyze(query));
        double[] score = new double[sentences.length];
        for (int i = 0; i < sentences.length; i++) {
            Set<String> terms = new HashSet<>(analyze(sentences[i]));
            terms.retainAll(queryTerms);
            score[i] = terms.size() + (i == 0 ? 0.5 : 0.0); // lead sentence gets a small bonus
        }
        List<Integer> order = new ArrayList<>();
        for (int i = 0; i < sentences.length; i++) order.add(i);
        order.sort((x, y) -> Double.compare(score[y], score[x]));
        List<Integer> chosen = new ArrayList<>(order.subList(0, 2));
        chosen.sort(Integer::compare);
        return sentences[chosen.get(0)] + " " + sentences[chosen.get(1)];
    }

    private List<String> analyze(String text) {
        List<String> out = new ArrayList<>();
        try (TokenStream ts = index.analyzer().tokenStream("text", text)) {
            CharTermAttribute term = ts.addAttribute(CharTermAttribute.class);
            ts.reset();
            while (ts.incrementToken()) out.add(term.toString());
            ts.end();
        } catch (IOException e) {
            // ignore: an empty list just means no overlap
        }
        return out;
    }

    // ------------------------------------------------------ related / suggest
    /** Similar articles in the same language, using Lucene MoreLikeThis (keyword-based similarity). */
    public List<Hit> related(String id, int n) {
        Article a = index.articles().get(id);
        if (a == null) return List.of();
        try {
            MoreLikeThis mlt = new MoreLikeThis(index.reader());
            mlt.setAnalyzer(index.analyzer());
            mlt.setFieldNames(new String[] {"title", "text"});
            mlt.setMinTermFreq(1);
            mlt.setMinDocFreq(1);
            mlt.setMaxQueryTerms(30);
            Query like = mlt.like("text", new StringReader(a.title() + " " + a.text()));
            IndexSearcher searcher = new IndexSearcher(index.reader());
            TopDocs top = searcher.search(withLang(like, a.lang()), n + 1);
            List<Hit> out = new ArrayList<>();
            for (ScoreDoc sd : top.scoreDocs) {
                String otherId = searcher.storedFields().document(sd.doc, Set.of("id")).get("id");
                if (otherId.equals(id)) continue;
                Article o = index.articles().get(otherId);
                if (o != null && out.size() < n) {
                    out.add(new Hit(o.id(), o.lang(), o.title(), o.titleEn(), null, null, o.url(), sd.score));
                }
            }
            return out;
        } catch (IOException e) {
            return List.of();
        }
    }

    /** Autocomplete: English prefix -> English titles (Trie), other scripts -> local titles (Trie). */
    public List<Suggestion> suggest(String prefix, String lang) {
        if (prefix == null || prefix.isBlank()) return List.of();
        String p = prefix.trim();
        boolean english = isLatin(p);
        List<Suggestion> out = new ArrayList<>();
        for (Trie.Entry e : (english ? trieEn : trie).startsWith(p, lang, 8)) {
            out.add(new Suggestion(english ? e.titleEn() : e.title(), e.title(), e.lang(), e.id()));
        }
        return out;
    }
}
