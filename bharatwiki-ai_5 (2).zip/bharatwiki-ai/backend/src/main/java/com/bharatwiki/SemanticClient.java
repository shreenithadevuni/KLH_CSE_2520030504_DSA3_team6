package com.bharatwiki;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/** Calls the optional Python semantic service. Returns empty if it is not running. */
@Component
public class SemanticClient {
    private static final Logger log = LoggerFactory.getLogger(SemanticClient.class);

    public record Scored(String id, double score) {}

    private final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(1)).build();
    private final ObjectMapper mapper = new ObjectMapper();

    @Value("${bharatwiki.semantic-url:}")
    private String baseUrl;

    public Optional<List<Scored>> search(String query, String lang, int k) {
        if (baseUrl == null || baseUrl.isBlank()) return Optional.empty();
        try {
            String url = baseUrl + "/semantic?q=" + URLEncoder.encode(query, StandardCharsets.UTF_8)
                    + "&lang=" + URLEncoder.encode(lang, StandardCharsets.UTF_8) + "&k=" + k;
            HttpRequest req = HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofSeconds(5)).GET().build();
            HttpResponse<String> res = http.send(req, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
            if (res.statusCode() != 200) return Optional.empty();
            List<Scored> out = new ArrayList<>();
            for (JsonNode n : mapper.readTree(res.body()).path("results")) {
                out.add(new Scored(n.path("id").asText(), n.path("score").asDouble()));
            }
            return Optional.of(out);
        } catch (Exception e) {
            log.debug("Semantic service unavailable: {}", e.toString());
            return Optional.empty();
        }
    }
}
