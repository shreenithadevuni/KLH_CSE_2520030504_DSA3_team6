package com.bharatwiki;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BharatWikiApplication {
    public static void main(String[] args) {
        SpringApplication.run(BharatWikiApplication.class, args);
    }
}
