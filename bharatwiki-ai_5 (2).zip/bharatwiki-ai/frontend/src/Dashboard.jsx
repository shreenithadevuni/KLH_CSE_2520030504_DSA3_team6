import { useEffect, useState } from "react";

const LANG_NAME = { en: "English", hi: "हिन्दी", te: "తెలుగు", ta: "தமிழ்", kn: "ಕನ್ನಡ", all: "All languages" };

function Bars({ title, data, format = (k) => k }) {
  const entries = Object.entries(data || {});
  const max = Math.max(1, ...entries.map(([, v]) => Number(v)));
  return (
    <section className="panel">
      <h3>{title}</h3>
      {entries.length === 0 && <p className="note">No data yet.</p>}
      {entries.map(([k, v]) => (
        <div className="bar-row" key={k}>
          <span className="bar-label">{format(k)}</span>
          <div className="bar-track"><div className="bar-fill" style={{ width: `${(Number(v) / max) * 100}%` }} /></div>
          <span className="bar-value">{v}</span>
        </div>
      ))}
    </section>
  );
}

export default function Dashboard() {
  const [d, setD] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    fetch("/api/analytics")
      .then((r) => (r.ok ? r.json() : Promise.reject(new Error(`status ${r.status}`))))
      .then(setD)
      .catch((e) => setError(`Could not load analytics (${e.message}).`));
  }, []);

  if (error) return <p className="error">{error}</p>;
  if (!d) return <p className="placeholder">Loading</p>;

  return (
    <main className="dash">
      <div className="stats">
        <div><strong>{d.totalSearches}</strong><span>searches so far</span></div>
        <div><strong>{d.avgLatencyMs} ms</strong><span>average response time</span></div>
        <div><strong>{d.p95LatencyMs} ms</strong><span>95th percentile (last 200)</span></div>
      </div>
      <div className="grid">
        <Bars title="Articles in the index, by language" data={d.corpusByLanguage} format={(k) => LANG_NAME[k] || k} />
        <Bars title="Searches by language filter" data={d.searchesByLanguage} format={(k) => LANG_NAME[k] || k} />
        <Bars title="Searches by ranking method" data={d.searchesByMode} />
        <Bars
          title="Most searched queries"
          data={Object.fromEntries((d.topQueries || []).map((t) => [t.query, t.count]))}
        />
      </div>
    </main>
  );
}
