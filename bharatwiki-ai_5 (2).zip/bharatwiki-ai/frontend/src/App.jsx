import { useEffect, useRef, useState } from "react";
import Dashboard from "./Dashboard.jsx";

const LANGS = [
  { code: "en", label: "English" },
  { code: "hi", label: "हिन्दी (Hindi)" },
  { code: "te", label: "తెలుగు (Telugu)" },
  { code: "ta", label: "தமிழ் (Tamil)" },
  { code: "kn", label: "ಕನ್ನಡ (Kannada)" },
];
const LANG_NAME = { en: "English", hi: "हिन्दी", te: "తెలుగు", ta: "தமிழ்", kn: "ಕನ್ನಡ" };
const MODES = [
  { code: "hybrid", label: "Hybrid", about: "Combines keyword matching with meaning-based search. Best overall." },
  { code: "bm25", label: "BM25", about: "Keyword search using the BM25 ranking formula, matched on English titles." },
  { code: "tfidf", label: "TF-IDF", about: "Classic keyword search that weighs rare words higher." },
  { code: "semantic", label: "Meaning", about: "Finds articles by meaning, even without matching words. Needs the Python service." },
];
const EXAMPLES = ["Taj Mahal", "ISRO", "Yoga", "Ayurveda", "Chess", "Diwali", "Indian Railways"];

export default function App() {
  const [tab, setTab] = useState("search");
  const [q, setQ] = useState("");
  const [lang, setLang] = useState("hi");
  const [mode, setMode] = useState("hybrid");
  const [data, setData] = useState(null);            // last search response
  const [asked, setAsked] = useState(null);          // {q, lang, mode} used for that response
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [suggestions, setSuggestions] = useState([]);
  const [related, setRelated] = useState({});
  const [full, setFull] = useState({});              // id -> full article text (or "loading")
  const skipSuggest = useRef(false);
  const inputRef = useRef(null);

  // ---- runs ONLY when the user clicks Search (or presses Enter in the box) ----
  async function onSearch(e) {
    e.preventDefault();
    const query = q.trim();
    if (!query) return;
    setSuggestions([]);
    setLoading(true);
    setError("");
    try {
      const params = new URLSearchParams({ q: query, lang, mode, size: "10" });
      const res = await fetch(`/api/search?${params}`);
      if (!res.ok) throw new Error(`server answered ${res.status}`);
      setData(await res.json());
      setAsked({ q: query, lang, mode });
      setRelated({});
      setFull({});
    } catch (err) {
      setError(`Could not reach the backend (${err.message}). Is Spring Boot running on port 8080?`);
    } finally {
      setLoading(false);
    }
  }

  // Autocomplete while typing: only fills a dropdown, never shows results.
  useEffect(() => {
    if (skipSuggest.current) {
      skipSuggest.current = false;
      return;
    }
    if (!q.trim()) {
      setSuggestions([]);
      return;
    }
    const timer = setTimeout(async () => {
      try {
        const res = await fetch(`/api/suggest?${new URLSearchParams({ q, lang })}`);
        if (res.ok) setSuggestions(await res.json());
      } catch {
        /* suggestions are optional */
      }
    }, 200);
    return () => clearTimeout(timer);
  }, [q, lang]);

  // Picking a suggestion / example only fills the box. The user still clicks Search.
  function fillBox(text) {
    skipSuggest.current = true;
    setQ(text);
    setSuggestions([]);
    setTab("search");
    inputRef.current?.focus();
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  async function toggleRelated(id) {
    if (related[id]) {
      setRelated((r) => ({ ...r, [id]: undefined }));
      return;
    }
    try {
      const res = await fetch(`/api/related?id=${encodeURIComponent(id)}`);
      const list = res.ok ? await res.json() : [];
      setRelated((r) => ({ ...r, [id]: list }));
    } catch {
      setRelated((r) => ({ ...r, [id]: [] }));
    }
  }

  async function toggleFull(id) {
    if (full[id] && full[id] !== "loading") {
      setFull((f) => ({ ...f, [id]: undefined }));
      return;
    }
    setFull((f) => ({ ...f, [id]: "loading" }));
    try {
      const res = await fetch(`/api/article?id=${encodeURIComponent(id)}`);
      const a = res.ok ? await res.json() : null;
      setFull((f) => ({ ...f, [id]: a ? a.text : "Could not load the article." }));
    } catch {
      setFull((f) => ({ ...f, [id]: "Could not load the article." }));
    }
  }

  const stale = data && asked && (asked.lang !== lang || asked.mode !== mode || asked.q !== q.trim());
  const maxScore = data?.hits?.length ? Math.max(...data.hits.map((h) => h.score)) || 1 : 1;
  const modeInfo = MODES.find((m) => m.code === mode);

  return (
    <div className="app">
      <header className="nav">
        <div className="nav-inner">
          <div className="logo">
            <span className="logo-mark" lang="hi" aria-hidden="true">भा</span>
            <span className="logo-text">BharatWiki <b>AI</b></span>
          </div>
          <nav className="tabs" role="tablist">
            <button role="tab" aria-selected={tab === "search"} onClick={() => setTab("search")}>Search</button>
            <button role="tab" aria-selected={tab === "dashboard"} onClick={() => setTab("dashboard")}>Dashboard</button>
          </nav>
        </div>
      </header>

      {tab === "dashboard" ? (
        <div className="container"><Dashboard /></div>
      ) : (
        <>
          <section className="hero">
            <div className="container">
              <h1>Ask in English.<br />Read in your language.</h1>
              <p className="lead">
                Search Wikipedia-style articles in Hindi, Telugu, Tamil and Kannada by typing the topic in English.
              </p>
              <p className="scripts" aria-hidden="true">
                <span lang="hi">खोज</span><span lang="te">వెతుకు</span><span lang="ta">தேடு</span><span lang="kn">ಹುಡುಕು</span>
              </p>

              <form className="card searchcard" onSubmit={onSearch}>
                <div className="row">
                  <label className="field grow">
                    <span className="field-label">Search in English</span>
                    <div className="inputwrap">
                      <svg className="icon" viewBox="0 0 24 24" width="20" height="20" aria-hidden="true">
                        <circle cx="11" cy="11" r="7" fill="none" stroke="currentColor" strokeWidth="2" />
                        <path d="M16.5 16.5L21 21" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                      </svg>
                      <input
                        ref={inputRef}
                        value={q}
                        onChange={(e) => setQ(e.target.value)}
                        onKeyDown={(e) => e.key === "Escape" && setSuggestions([])}
                        onBlur={() => setTimeout(() => setSuggestions([]), 120)}
                        placeholder="e.g. Taj Mahal, Chandrayaan, Yoga"
                        autoComplete="off"
                        autoFocus
                      />
                      {suggestions.length > 0 && (
                        <ul className="suggest" role="listbox">
                          {suggestions.map((s) => (
                            <li key={s.id} role="option" onMouseDown={() => fillBox(s.label)}>
                              <span>{s.label}</span>
                              <em lang={s.lang}>{s.local !== s.label ? s.local : LANG_NAME[s.lang]}</em>
                            </li>
                          ))}
                        </ul>
                      )}
                    </div>
                  </label>
                  <label className="field">
                    <span className="field-label">Show results in</span>
                    <select value={lang} onChange={(e) => setLang(e.target.value)}>
                      {LANGS.map((l) => (
                        <option key={l.code} value={l.code}>{l.label}</option>
                      ))}
                    </select>
                  </label>
                  <button type="submit" className="go" disabled={loading || !q.trim()}>
                    {loading ? "Searching" : "Search"}
                  </button>
                </div>

                <div className="modes-row">
                  <span className="field-label">Ranking</span>
                  <div className="seg" role="radiogroup" aria-label="Ranking method">
                    {MODES.map((m) => (
                      <button
                        key={m.code}
                        type="button"
                        role="radio"
                        aria-checked={mode === m.code}
                        className={mode === m.code ? "seg-btn on" : "seg-btn"}
                        onClick={() => setMode(m.code)}
                      >
                        {m.label}
                      </button>
                    ))}
                  </div>
                </div>
                <p className="mode-about">{modeInfo.about}</p>
              </form>

              <div className="examples">
                <span>Try</span>
                {EXAMPLES.map((ex) => (
                  <button key={ex} type="button" className="chipbtn" onClick={() => fillBox(ex)}>{ex}</button>
                ))}
              </div>
            </div>
          </section>

          <main className="container results" aria-live="polite">
            {error && <p className="error">{error}</p>}

            {loading && (
              <div className="skeletons" aria-label="Loading results">
                {[0, 1, 2].map((i) => (
                  <div className="card sk" key={i}><i /><i /><i className="short" /></div>
                ))}
              </div>
            )}

            {!loading && data && (
              <>
                <div className="summarybar">
                  <h2>
                    {data.total} result{data.total === 1 ? "" : "s"} for “{asked.q}” in{" "}
                    <span lang={asked.lang}>{LANG_NAME[asked.lang]}</span>
                  </h2>
                  <p>
                    <span>{data.tookMs} ms</span>
                    <span>{MODES.find((m) => m.code === asked.mode)?.label} ranking</span>
                  </p>
                </div>
                {stale && <p className="note">You changed the search options. Press Search to update the results.</p>}
                {data.note && <p className="note">{data.note}</p>}
                {data.hits.length === 0 && !data.note && (
                  <div className="card empty">
                    <strong>No articles matched.</strong>
                    <span>Try a different English word, or another language.</span>
                  </div>
                )}

                {data.hits.map((h) => (
                  <article key={h.id} className="card hit">
                    <header>
                      <div className="titles">
                        <h3 lang={h.lang}>
                          {h.url ? <a href={h.url} target="_blank" rel="noreferrer">{h.title}</a> : h.title}
                        </h3>
                        {h.titleEn && <span className="en-title">{h.titleEn}</span>}
                      </div>
                      <span className={`badge b-${h.lang}`} lang={h.lang}>{LANG_NAME[h.lang]}</span>
                    </header>

                    <div className="rel" title={`Relevance score ${h.score.toFixed(3)}`}>
                      <span>Relevance</span>
                      <div className="rel-track"><div className="rel-fill" style={{ width: `${Math.max(6, (h.score / maxScore) * 100)}%` }} /></div>
                    </div>

                    {/* The server HTML-escapes everything except its own <mark> tags, so this is safe */}
                    <p className="snippet" lang={h.lang} dangerouslySetInnerHTML={{ __html: h.snippet }} />
                    <div className="summary" lang={h.lang}>
                      <span className="tag">Summary</span>
                      <p>{h.summary}</p>
                    </div>

                    {full[h.id] && (
                      <div className="fulltext" lang={h.lang}>
                        <span className="tag">Full article</span>
                        <p>{full[h.id] === "loading" ? "Loading" : full[h.id]}</p>
                      </div>
                    )}

                    <div className="actions">
                      <button className="btn" onClick={() => toggleFull(h.id)}>
                        {full[h.id] ? "Hide full article" : "Read full article"}
                      </button>
                      <button className="btn ghost" onClick={() => toggleRelated(h.id)}>
                        {related[h.id] ? "Hide related" : "Related articles"}
                      </button>
                    </div>

                    {related[h.id] && (
                      <ul className="related">
                        {related[h.id].length === 0 && <li className="muted">No related articles found.</li>}
                        {related[h.id].map((r) => (
                          <li key={r.id}>
                            <button className="linkbtn" lang={r.lang} onClick={() => fillBox(r.titleEn || r.title)}>
                              {r.title}{r.titleEn ? ` (${r.titleEn})` : ""}
                            </button>
                          </li>
                        ))}
                      </ul>
                    )}
                  </article>
                ))}
              </>
            )}

            {!loading && !data && !error && (
              <p className="placeholder">Type a topic, pick a language and press <b>Search</b>. Results appear here.</p>
            )}
          </main>
        </>
      )}

      <footer className="foot">
        <div className="container">
          BharatWiki AI &nbsp;|&nbsp; Hybrid keyword and semantic search with Apache Lucene, Spring Boot and React
        </div>
      </footer>
    </div>
  );
}
