# BharatWiki AI

**Search in English, choose a language, read the article in that language.**
Cross-lingual search over Hindi, Telugu, Tamil and Kannada Wikipedia.

Example: type `Taj Mahal`, select *Telugu* -> the Telugu article "తాజ్ మహల్" with a Telugu snippet and summary.

How an English query finds a Telugu article (two routes, fused with Reciprocal Rank Fusion):
1. **Keyword route** - every article stores its English title (`title_en`); BM25 matches the English query against it.
2. **Meaning route** - a multilingual embedding model puts English and Indian-language text in one shared meaning space,
   so even "white marble tomb in Agra" finds the Taj Mahal article. (Needs the optional Python service, step 4.)

You can also type in Hindi/Telugu/Tamil/Kannada: non-English queries search the local-language text directly.

```
Wikipedia subset (JSONL) --> Lucene index (BM25 / TF-IDF) --\
                         \-> embeddings (Python, optional) ---> Spring Boot API --> React UI
                                                                      |
                                                              H2 / PostgreSQL (search logs -> dashboard)
```

| Folder | What it is |
|---|---|
| `data/` | `sample_articles.jsonl` = 24 tiny demo articles (6 topics x 4 languages, written for this demo, NOT Wikipedia text) |
| `tools/` | Python: `dsa_index.py` (own inverted index, TF-IDF, BM25, min-heap, Trie), `evaluate.py`, `download_wikipedia.py`, `semantic_service.py` |
| `backend/` | Spring Boot + Lucene REST API (`/api/search`, `/suggest`, `/related`, `/article`, `/analytics`) |
| `frontend/` | React (Vite) search page + analytics dashboard |
| `eval/queries.json` | Test queries with the correct answers (extend this!) |

## 0. Install once
- Java 17+ and **Maven** (or just open `backend/pom.xml` in IntelliJ IDEA, which has Maven built in)
- Node.js 18+
- Python 3.10+

## 1. Run the demo (about 5 minutes, no database setup)

Open **two terminals**.

**Terminal 1 - backend**
```bash
cd backend
mvn spring-boot:run
```
Wait for `Indexed 24 articles in ... ms` and `Started BharatWikiApplication`.
Test: open http://localhost:8080/api/search?q=Taj%20Mahal&lang=te&mode=bm25

**Terminal 2 - frontend**
```bash
cd frontend
npm install
npm run dev
```
Open http://localhost:5173, type in English (`Taj Mahal`, `Hyderabad`, `Yoga`, `Cricket`, `Mahatma Gandhi`, `Ganga`),
pick the language in **Show results in**, and read the result in that language.
Results appear **only after you click Search** (or press Enter). Typing shows autocomplete suggestions (Trie), and picking a
suggestion, an example chip or a related article only fills the search box. Changing the language or ranking after a search does
not re-run it; the page tells you to press Search again. Each result has **Read full article** and **Related articles** buttons.
Click "Dashboard" for analytics.

Without the semantic service, "Hybrid" shows a yellow note and uses English-title keyword matching only (so `Taj Mahal` works,
but a description like `white marble tomb in Agra` needs step 4). That is expected.

## 2. Evaluate your own index (Python, nothing to install)
```bash
cd tools
python evaluate.py
```
Runs two query sets - English queries -> chosen language (`eval/queries_en.json`) and same-language queries (`eval/queries.json`) -
and prints MRR, Success@1/3 and latency for TF-IDF, BM25 and a linear-scan baseline.
On the 24-article demo all systems score 1.000 - that proves the code works, NOT that the search is good.
Real numbers need real data (step 3) and your own test queries.

## 3. Use real Wikipedia data
```bash
cd tools
pip install datasets
python download_wikipedia.py --per-lang 10000 --out ../data/articles.jsonl
python add_english_titles.py --in ../data/articles.jsonl --out ../data/articles_en.jsonl
```
The second script asks Wikipedia for the English title of each article (its "In other languages" link) and stores it as `title_en`.
It needs internet and takes a while (about 200 requests per language). Articles with no English counterpart are still found by meaning.

Then point the backend at the new file - edit `backend/src/main/resources/application.properties`:
```
bharatwiki.data-path=../data/articles_en.jsonl
```
Restart the backend (it rebuilds the index at startup) and run `python evaluate.py --data ../data/articles_en.jsonl`.
Add 20-30 English queries per language to `eval/queries_en.json` (query + target language + ids of the correct articles).
Wikipedia text is CC BY-SA: keep the URLs and credit Wikipedia in your report.

## 4. Turn on semantic (meaning) search - optional
```bash
cd tools
pip install fastapi uvicorn sentence-transformers numpy
python -m uvicorn semantic_service:app --port 8001
```
The first start downloads the multilingual model (a few hundred MB) and embeds all articles once (cached in `tools/.cache`).
If you changed the data path, use the same file: `DATA_PATH=../data/articles_en.jsonl python -m uvicorn semantic_service:app --port 8001`.
Reload the page: Hybrid and Meaning modes now work.

## 5. PostgreSQL instead of H2 - optional
```bash
docker compose up -d
cd backend
mvn spring-boot:run -Dspring-boot.run.profiles=postgres
```

## Topics in the demo data (60 topics x 5 languages = 300 articles)
Each article has a local-language title, an English title (`title_en`) and a longer reading text (6-8 sentences).
Search any of these in English and choose English, Hindi, Telugu, Tamil or Kannada:

- **Technology:** Artificial Intelligence, Machine Learning, Computer Science, Internet, Robotics
- **Energy and space:** Solar Energy, Renewable Energy, Space Exploration, Chandrayaan, ISRO
- **Culture and festivals:** Yoga, Diwali, Holi, Sankranti, Ugadi, Indian Classical Music, Bharatanatyam, Kuchipudi, Indian Cuisine, Indian Languages
- **Sports:** Cricket, Field Hockey, Badminton, Chess, Olympic Games
- **Society and science:** Education in India, Indian Railways, Agriculture, Ayurveda, Biodiversity
- **First demo set:** Hyderabad, Taj Mahal, Mahatma Gandhi, Ganga River
- **Cities and states:** Mumbai, Delhi, Bengaluru, Chennai, Kolkata, Kerala
- **Places and nature:** Himalayas, Western Ghats, Monsoon, Red Fort, Charminar, Golconda Fort
- **People and history:** Rabindranath Tagore, B. R. Ambedkar, A. P. J. Abdul Kalam, Constitution of India, Indian Independence Movement, Aryabhata
- **More topics:** Mangalyaan, Indian Cinema, Onam, Durga Puja, Kabaddi, UPI, Ramayana, Mahabharata

The texts were written for this demo (not copied from Wikipedia) and should be proof-read by a native speaker before you
present them as content. For the real thing, use step 3 (real Wikipedia) - Wikipedia already has articles on all these topics.

## Known limits (say these in your viva)
- The keyword route only finds articles that have an English title; the meaning route covers the rest. The small multilingual model is weaker for Telugu and Kannada than for Hindi - measure it, and try `EMBED_MODEL=intfloat/multilingual-e5-base` if quality is poor.
- Results are limited to articles that exist in the chosen language; this is search, not translation of articles.
- One analyzer (Unicode tokenizer + Indic normalization + small stop-word list) is used for all four languages; Lucene has a dedicated analyzer only for Hindi, and there is no stemming.
- Vectors are searched with a numpy matrix, fine for tens of thousands of articles; use pgvector or FAISS beyond that.
- Summaries are extractive (real sentences chosen from the article), not AI-generated.
- "Related articles" uses keyword similarity (Lucene MoreLikeThis), same language only.
- The index is rebuilt at every backend start (simple, but slow for very large data).
